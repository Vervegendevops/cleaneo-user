package com.example.cleaneo_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
