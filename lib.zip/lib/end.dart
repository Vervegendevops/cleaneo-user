import 'package:flutter/material.dart';

class end extends StatefulWidget {
  const end({super.key});

  @override
  State<end> createState() => _endState();
}

class _endState extends State<end> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: Text('hello everyone')),
    );
  }
}
