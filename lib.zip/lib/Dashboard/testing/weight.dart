import 'package:flutter/material.dart';

class weightPage extends StatefulWidget {
  const weightPage({super.key});

  @override
  State<weightPage> createState() => _weightPageState();
}

class _weightPageState extends State<weightPage> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
