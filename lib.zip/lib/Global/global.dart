import 'package:get_storage/get_storage.dart';

String Loginphone = "";
String Signupname = "";
String Signupphone = "";
String Signupemail = "";
final UserData = GetStorage();
String UserID = '';
